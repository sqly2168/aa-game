<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <title>Bejelentkezés</title>
       <link rel="stylesheet" type="text/css" href="register.css">
</head>

<body>
       <form action="handle_login.php" method="post">
              <label for="username">Felhasználónév:</label>
              <input type="text" name="username" id="username" required>
              <label for="password">Jelszó:</label>
              <input type="password" name="password" id="password" required>
              <input type="submit" value="Bejelentkezés">
              <?php
              if (isset($_SESSION['login_error'])) {
                     echo '<p class="error-message">' . $_SESSION['login_error'] . '</p>';
                     unset($_SESSION['login_error']);
              }
              ?>
       </form>
</body>

</html>