User
<?php

session_start();

function kapcsolodas($kapcsolati_szoveg, $felhasznalonev = '', $jelszo = ''){
    $pdo = new PDO($kapcsolati_szoveg, $felhasznalonev, $jelszo);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $pdo;
}

$kapcsolat = kapcsolodas('mysql:host=mysql.caesar.elte.hu;dbname=sqly', 'sqly', '8KybPfrY0nGMt9t0');


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $felhasznalonev = $_POST['username'];
    $jelszo = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $kapcsolat->prepare("INSERT INTO felhasznalok (felhasznalonev, jelszo) VALUES (:felhasznalonev, :jelszo)");

    $stmt->execute([
        'felhasznalonev' => $felhasznalonev,
        'jelszo' => $jelszo,
    ]);

    $_SESSION['registration_success'] = true;

    header('Location: index.php');
    exit();
}
?>