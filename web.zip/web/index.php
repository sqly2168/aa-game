<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" type="text/css" href="register.css">
</head>

<body>

    <form action="handle_registration.php" method="post">
        <label for="username">Felhasználónév:</label>
        <input type="text" name="username" id="username" required>
        <label for="password">Jelszó:</label>
        <input type="password" name="password" id="password" required>
        <input type="submit" value="Regisztráció">

        <?php
        if (isset($_SESSION['registration_success']) && $_SESSION['registration_success']) {
            echo '<p class="success-message">Sikeres regisztráció! :)</p>';
            unset($_SESSION['registration_success']);
            echo '<script>
                    setTimeout(function(){
                        window.location.href = "login.php";
                    }, 3000);
                  </script>';
        }
        ?>
    </form>
</body>

</html>
