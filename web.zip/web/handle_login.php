<?php

session_start();

require('connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $stmt = $kapcsolat->prepare("SELECT id, felhasznalonev, jelszo FROM felhasznalok WHERE felhasznalonev = :username");
    $stmt->execute(["username" => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['jelszo'])) {
        $_SESSION["login_success"] = true;
        $_SESSION["id"] = $user['id'];
        header('Location: jatek.html');
        exit();
    } else {
        $_SESSION["login_error"] = "Hibás felhasználónév vagy jelszó :c";
        header('Location: login.php');
        exit();
    }
}
?>

